
#Simple Login With Codeigniter
Simple Login Codeigniter ini saya buat untuk mempermudah temen - temen ketika membuat halaman login admin. 

#Fitur
- Session
- Flashdata (digunakan untuk informasi login berhasil atau tidak)
- Logout Session 
- Template Sederhana dari W3layouts.com

#Berkontribusi ?
- Saya sangat terbuka jika temen-temen mau mengoprek lebih jauh lagi :D

#Sample Database
- username : indrakusuma
- password : indrakusuma (md5)

#Thanks To
- Allah SWT
- Bapak & Ibu
- W3Layouts & Codeigniter 
